/**
 * 
 */
package edu.ics211.h02;

/**
 * @author Ruben Jacobo
 *        Partnered w/ Gavin Peng
 *
 */
public class MotherNature implements CloudCreator {
    private static MotherNature instance;
  /**
   * 
   */
  public static MotherNature getInstance() {
    if( instance == null) {
      instance = new MotherNature();
    }
    return instance;
  }
  
  
  
  public MotherNature() {
    // TODO Auto-generated constructor stub
  }

  /**
   * conditionals to return proper cloud type
   *
   */ 
  @Override
  public Cloud formACloud(Integer altitude, CloudShape shape) {
    //conditionals to determine if this is cumulus cloud
    if(altitude<6500 && CloudShape.CUMULO==shape) {
      return new Cumulus(altitude);}
  //conditionals to determine if this is altostratus cloud
    else if((altitude > 6501 && altitude < 19999) && CloudShape.STRATO==shape) {
      return new Altostratus(altitude);
    }
  //conditionals to determine if this is cirrostratus cloud
    else if(altitude > 19999 && CloudShape.STRATO==shape) {
      return new Cirrostratus(altitude);
    } 
  //conditionals to determine if this is cirrus cloud
    else if(altitude > 19999 && CloudShape.CIRRO==shape) {
      return new Cirrus(altitude);
    } 
    // if none of the conditionals are met, altitude is invalid
    else {
      throw new IllegalArgumentException();
      //throw an exception if this is the case
    }
  }

  /**
   * return proper cloud type
   *
   */ 
  @Override
  public Cloud formAHighLevelCloud(CloudShape shape) {
    switch(shape) {
      //switch statement to return proper cloud based on the cloudshape
      case STRATO: return new Cirrostratus();
      //if STRATO shaped, return Cirrostratus
      case CIRRO: return new Cirrus();
      //if CIRRO is the cloudshape, return Cirris
      default: throw new IllegalArgumentException();
      //otherwise, throw an exception
    }
    
    
  }

  @Override
public Cloud formAMidLevelCloud(CloudShape shape) {
    //conditionals to determine which cloud type to return
    if (CloudShape.STRATO == shape) {
      //return Altostratus if cloudshape is STRATO
      return new Altostratus();
    } 
    //otherwise, throw an exception
    else { throw new IllegalArgumentException();
    }
  }


  @Override
 public Cloud formALowLevelCloud(CloudShape shape) {
    //conditionals to determine which cloud to return
    if(CloudShape.CUMULO==shape) {
      // if the cloudshape is a CUMULO, return a cumulus cloud
      return new Cumulus();
    } else {
      //otherwise, throw an exception
      throw new IllegalArgumentException();
    }
  }


}
