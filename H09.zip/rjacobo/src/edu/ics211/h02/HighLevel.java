/**
 * 
 */
package edu.ics211.h02;

/**
 * @author Ruben Jacobo
 *
 */
public abstract class HighLevel extends Cloud {

  /**
   * @param altitude
   * @param shape
   * 
   * determine if it is a high level cloud
   */
  public HighLevel(Integer altitude, CloudShape shape) {
    super(altitude, shape);
    // conditional to prove if it's altitude is appropriate for high level cloud
    if(altitude<20000) {
      throw new IllegalArgumentException();
      //if invalid altitude, throw this exception
    }
  }

}
