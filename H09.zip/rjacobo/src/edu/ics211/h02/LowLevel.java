/**
 * 
 */
package edu.ics211.h02;

/**
 * @author Ruben Jacobo
 *
 */
public abstract class LowLevel extends Cloud {

  /**
   * @param altitude
   * @param shape
   * 
   * determines if cloud is lowlevel
   */
  public LowLevel(Integer altitude, CloudShape shape) {
    super(altitude,shape);
    // conditional to test if the altitude matches with a low level cloud
    if(altitude>6500) {
      throw new IllegalArgumentException();
    //if invalid altitude, throw this exception
    }
  }

}
