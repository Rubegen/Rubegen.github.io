/**
 * 
 */
package edu.ics211.h02;

import java.util.Random;

/**
 * @author Ruben Jacobo
 *
 */
public class Cumulus extends LowLevel {
  
  
  /**
   * no arguments constructor that sets altitude to a random number
   *
   */ 
  public Cumulus() {
    super(500, CloudShape.CUMULO);
    Random rand = new Random();
    setAltitude(rand.nextInt(6501));
  }

  /**
   * @param altitude
   * constructor with parameter altitude
   */
  public Cumulus(Integer altitude) {
    super(altitude, CloudShape.CUMULO);
    // TODO Auto-generated constructor stub
  }

}
