/**
 * 
 */
package edu.ics211.h02;

import java.util.Random;

/**
 * @author Ruben Jacobo
 *
 */
public class Altostratus extends MidLevel {

  /**
   * @param altitude
   * @param shape
   */
  public Altostratus(Integer altitude) {
    super(altitude, CloudShape.STRATO);
    // TODO Auto-generated constructor stub
  }
  
  /**
   *returns a valid altitude
   */ 
  private static Integer getValidAltitude() {
    Random random = new Random();
    return random.nextInt(20000 - 6501)+ 6501;
  }
  
  /**
   * 
   * no arguments constructor
   */ 
  public Altostratus() { 
    super(getValidAltitude(), CloudShape.STRATO);
  }

}
