/**
 * 
 */
package edu.ics211.h02;

import java.util.Random;

/**
 * @author Ruben Jacobo
 *
 */
public class Cirrus extends HighLevel {

  /**
   * @param altitude
   * @param shape
   */
  public Cirrus(Integer altitude) {
    super(altitude, CloudShape.CIRRO);
    // TODO Auto-generated constructor stub
  }
  
  /**
   * no arguments constructor
   * sets altitude appropriately
   */ 
  public Cirrus() {
    super(20100, CloudShape.CIRRO);
    Random random = new Random();
    setAltitude(random.nextInt(15000)+20000);
  }

}
