/**
 * 
 */
package edu.ics211.h02;

/**
 * @author Ruben Jacobo
 *
 */
public abstract class MidLevel extends Cloud {

  /**
   * @param altitude
   * @param shape
   * 
   * determine is cloud is MidLevel
   */
  public MidLevel(Integer altitude, CloudShape shape) {
    super(altitude, shape);
    // conditional to test if it is a mid level cloud
    if(altitude<6501 || altitude>19999) {
      throw new IllegalArgumentException();
    //if invalid altitude, throw this exception
    }
  }

}
