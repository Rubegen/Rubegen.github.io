package edu.ics211.h02;

import java.util.Comparator;

/** This is my code.
 * @author Ruben Jacobo
 *
 */
public class AltitudeComparator implements Comparator<Cloud> {

  /**This is my code.
   * 
   */
  public AltitudeComparator() {
    // TODO Auto-generated constructor stub
  }

  @Override
  public int compare(Cloud o1, Cloud o2) {
    int diff = o1.getAltitude().compareTo(o2.getAltitude());
    return diff;
  }

}
