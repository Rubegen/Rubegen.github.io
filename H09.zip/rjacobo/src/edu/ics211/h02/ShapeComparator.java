package edu.ics211.h02;

import java.util.Comparator;

/** This is my code.
 * @author Ruben Jacobo
 *
 */
public class ShapeComparator implements Comparator<Cloud> {

  /** This is my code.
   * 
   */
  public ShapeComparator() {
    // TODO Auto-generated constructor stub
  }

  @Override
  public int compare(Cloud o1, Cloud o2) {
    int diff = o1.getShape().compareTo(o2.getShape());
    return diff;
  }

}
