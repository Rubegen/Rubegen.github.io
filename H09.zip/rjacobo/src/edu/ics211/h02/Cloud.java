/**
 * 
 */
package edu.ics211.h02;

/**
 * @author Ruben Jacobo
 *
 */
public abstract class Cloud {
  private Integer altitude;
  private CloudShape shape;

  /**
   * sets altitude and shape to their variable names
   */
  protected Cloud(Integer altitude, CloudShape shape) {
    // TODO Auto-generated constructor stub
    this.altitude = altitude;
    this.shape = shape;
  }
 
  /**
   * 
   * returns altitude when called
   */
  public Integer getAltitude() {
    return altitude;
  }
  
  /**
   * sets altitude to this.altitude
   */
  public void setAltitude(Integer altitude) {
    this.altitude=altitude;
  }
  
  /**
   * gets the shape of the cloud from CloudShape
   */
  public CloudShape getShape() {
    return shape;
  }
  
  /**
   * Sets the shape of the cloud from CloudShape
   */
  public void setShape(CloudShape shape) {
    this.shape=shape;
  }

}
