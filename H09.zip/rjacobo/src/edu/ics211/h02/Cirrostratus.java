/**
 * 
 */
package edu.ics211.h02;

import java.util.Random;

/**
 * @author Ruben Jacobo
 *
 */
public class Cirrostratus extends HighLevel {
  
  
  
  /**
   * sets a valid altitude for this cloud type
   *
   */   
  public Cirrostratus() {
      super(20100, CloudShape.STRATO);
      Random random = new Random();
      setAltitude(random.nextInt(15000)+20000);
    }

  /**
   * @param altitude
   * @param shape
   */
  public Cirrostratus(Integer altitude) {
    super(altitude, CloudShape.STRATO);
    // TODO Auto-generated constructor stub
  }

}
