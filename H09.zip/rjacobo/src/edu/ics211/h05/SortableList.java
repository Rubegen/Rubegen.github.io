package edu.ics211.h05;


import edu.ics211.h04.IList211;
import edu.ics211.h04.ISortableList;
import java.util.Comparator;



/** This is my code.
 * @author Ruben Jacobo
 *
 */
public class SortableList<E> implements IList211<E>, ISortableList<E> {
  private DLinkedNode tail;
  private int size;
  private int swaps;
  private int comps;
  private long time;
  
  
  
  public class DLinkedNode {
    E item;
    DLinkedNode next;
    DLinkedNode prev;
   
    public DLinkedNode(E item, DLinkedNode next, DLinkedNode prev) {
      this.item = item;
      this.next = next;
      this.prev = prev;
    }
  }
  
  @Override
  public void insertionSort(Comparator<E> compare) {
    // reset swaps and comparisons
    swaps = 0;
    comps = 0;
    // get start time
    final long startTime = System.nanoTime();
    boolean swapped;
    // loops from 1 to data.length - 1
    for (int i = 1; i < size; i++) {
      swapped = false;
      // remember the item at 1
      E key = get(i);
      int j = i;
      // while the hole isn't at 0 and the thing to the left of the hole is greater than remembered
      while (j > 0 && compare.compare(get(j - 1), key) > 0) {
        comps++;
        // swap the elements
        set(j, get(j - 1));
        //data[j] = data[j - 1];
        swaps++;
        swapped = true;
        j--;
      }
      if (j != 0) {
        comps++;
      }
      if (swapped) {
        set(j, key);
        //data[j] = key;
      }

    }

    // get end time
    long endTime = System.nanoTime();
    // calculates sorting time by end time minus start time
    time = endTime - startTime;
    
  }

  @Override
  public void bubbleSort(Comparator<E> compare) {
    // reset swaps and comparisons
    swaps = 0;
    comps = 0;
    // get start time
    final long startTime = System.nanoTime();

    boolean sort;
    do {
      // there are no more sorts
      sort = false;
      // loop through the length of the array
      for (int i = 0; i < size - 1 - swaps; i++) {
        // count # of comparisons
        comps++;
        // compare data[i] and data[i + 1] if > 0 swap and count swap
        if (compare.compare(get(i), get(i + 1)) > 0) {
          // swap the elements
          E temp = get(i);
          //data[i] = data[i + 1];
          set(i, get(i + 1));
          //data[i + 1] = temp;
          set(i + 1, temp);
          // sorting still happening
          sort = true;
          // count # of swaps
          swaps++;
        }
      }
    } while (sort);
    // get end time
    long endTime = System.nanoTime();
    // calculates sorting time by end time minus start time
    time = endTime - startTime;
    
    
  }

  @Override
  public void selectionSort(Comparator<E> compare) {
    // reset swaps and comparisons
    swaps = 0;
    comps = 0;
    // get start time
    final long startTime = System.nanoTime();

    // loop from 0 to data.length - 1
    for (int i = 0; i < size - 1; i++) {
      // Set current minimum value to i-0;
      int posMin = i;
      // Loops through the array 1 ahead of i
      for (int j = i + 1; j < size; j++) {
        // count # of comparisons
        comps++;
        // Compare the elements in the inner loop with the element
        if (compare.compare(get(j), get(posMin)) < 0) {
          // Set new current minimum value
          posMin = j;
        }
      }

      // Swap the minimum element with current element
      if (i != posMin) {
        E temp = get(i);
        //data[i] = data[posMin];
        set(i, get(posMin));
        //data[posMin] = temp;
        set(posMin, temp);
        // count # of swaps
        swaps++;
      }
    }
    // get end time
    long endTime = System.nanoTime();
    // calculates sorting time by end time minus start time
    time = endTime - startTime;
    
  }

  @Override
  public int getNumberOfSwaps() {
    // return swaps
    return swaps;
  }

  @Override
  public int getNumberOfComparisons() {
    // return comparisons
    return comps;
  }

  @Override
  public double getSortTime() {
    // return time to sort
    return time;
  }

  private void checkIndex(int index) {
    if (index < 0 || index >= size) {
      throw new IndexOutOfBoundsException();
      //throw an exception if the index given is out of bounds
    }
  }
  
  @Override
  public E get(int index) {
    checkIndex(index);
    
    DLinkedNode temp = tail;
    // temporary variable to traverse down, starting at tail
    for (int i = size - 1; i > index; i--) {
      //temp goes down the list after every loop
      temp = temp.prev;
      //when i becomes equal to index, break loop
    }
    //return the item at temp 
    return temp.item;

  }

  @Override
  public E set(int index, E element) {
    checkIndex(index);
    //check validity of index
    DLinkedNode temp = tail;
    //temporary variable to keep track of tail
    for (int i = size - 1; i > index; i--) {
      temp = temp.prev;
      //travers down the list
    }
    //keep track of the old value
    E oldVal = temp.item;
    //replace the item at temp with element
    temp.item = element;
    return oldVal; 
    //return the oldVal
  }

  @Override
  public int indexOf(Object obj) {
    int index = 0;
    for (int i = size - 1; i >= 0; i--) {
      E tester = get(i);
      //get the item at i
      if (obj == tester) {
        //compare the item to the object were looking for
        index = i;
        return index;
        //if a match is found, return the index it was found at
      }
    }
    //if not match was found, return -1
    return -1;
  }

  @Override
  public int size() {
    // return the size
    return size;
  }

  @Override
  public boolean add(E e) {
    //call the other add method and place e at the end of the list
    add(size, e);
    return true;
    //return true when done
  }

  @Override
  public void add(int index, E element) {
    DLinkedNode temp = tail;
    // check validity of index, this time index can be equal to size
    if (index < 0 || index > size) {
      throw new IndexOutOfBoundsException(); 
    }
    //throw an exception if the index given is out of bounds 
    if (size == 0) {
      tail = new DLinkedNode(element, null, null); }
    //if size is 0, add this new node and name it tail with next and prev being null
       
    else if (index == size) {     
      if (tail != null) { 
        //make sure tail is not null
        DLinkedNode upTail = new DLinkedNode(element, null, tail);
        //new node with previous tail before it and null after it
        tail.next = upTail;
        tail = upTail;
        //reassign tail to the last item added
        tail.prev = temp;
        //temp is now the item before the newly updated tail
      }   
    
    } else {
      
      for (int i = size - 1; i > index; i--) {
        temp = temp.prev;
      } //traverse from tail to index with this for loop
      DLinkedNode nodeNew = new DLinkedNode(element, temp, temp.prev);
      // new node
      if (temp.prev != null) {
        temp.prev.next = nodeNew;
        // point the next from the prev of temp to newNode
      }
      if (temp.next != null) {
        //make sure next and prev are not null first
        temp.next.prev = nodeNew;
        // point the prev of temp.next to the new Node
      }
      
      
      
    }
    //increment the size
    size++;
  }

  @Override
  public E remove(int index) {
    DLinkedNode temp = tail;
    // set the temp to tail
    checkIndex(index);
    for (int i = size - 1; i > index; i--) {
      temp = temp.prev; 
      //traverse from the tail of the list, to the given index
    }
    if (index == size - 1) {
      //if given index is the last item in the list
      if (temp.prev != null) {
        //make sure the previous item is not null first
        temp.prev.next = temp.next;
        // point things to the right place
        tail = temp.next;
      }
    
    } else {
      if (temp.prev != null) {
        //make sure the prev is not null
        temp.prev.next = temp.next;
        //reassign the values to point to the correct place
      }
      if (temp.next != null) {
        //make sure temp.next is not null
        temp.next.prev = temp.prev;
        //point it to the right place
      }
    }
    size--;
    //decrement size and return the removed item
    return temp.item;
  }
  

}

 
