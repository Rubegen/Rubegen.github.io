package edu.ics211.h08;

import java.util.ArrayList;
import java.util.List;

public class Router implements RouterInterface {

  private PacketQueue[] queues;
  private PacketSenderInterface sender;
  private List<Packet> droppedPackets;
  
  /**Creates a new router.
   * 
   * @param sender the sender.
   */
  public Router(PacketSenderInterface sender) {
    //initalize the member variables
    queues = new PacketQueue[8];
    for (int i = 0; i < queues.length; i++) {
      queues[i] = new PacketQueue();
    }
    this.sender = sender;
    droppedPackets = new ArrayList<Packet>();
  }
  
  
  @Override
  public void advanceTime() {
    //loop over the packetQueues
    for (int i = 0; i < queues.length; i++) {
      Packet packet = queues[i].poll();
      if (packet != null) {
        sender.send(i, packet);
      }
    }
  }

  @Override
  public boolean acceptPacket(Packet p) {
    //get p's adress
    for (int i = 0; i < 8; i++) {
      if (i == p.getAddress()) {
        if (queues[i].size() >= 10) {
          droppedPackets.add(p);
          break;
        } else {
          queues[i].offer(p);
          return true; 
        }
      }
    }
    return false;
  }

  @Override
  public List<Packet> getDroppedPackets() {
    // remember droppedPacket
    List<Packet> remember;
    remember = droppedPackets;
    droppedPackets = new ArrayList<Packet>();
    // initialize droppedPacket
    // return remember
    return remember;
  }

}
