package edu.ics211.h08;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Queue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



/**Testing PacketQueue implementation methods.
 * @author Ruben Jacobo
 *     partnered with Louie Bala, Gavin Peng
 */
class QueueTest {

  /** Testing the PacketQueue class methods.
   * 
   * @throws Exception when out of bounds.
   */
  @BeforeEach
  void setUp() throws Exception {
  }

  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#PacketQueue()}.
   */
  @Test
  void testPacketQueue() {
    assertNotNull(new PacketQueue());
  }
  
  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#size()}.
   */
  @Test
  void testSize() {
    PacketQueue p = new PacketQueue();
    // empty queue
    assertEquals(Integer.valueOf(0), p.size());
    // queue with one element
    p.offer(new Packet(1));
    assertEquals(Integer.valueOf(1), p.size());
    // fill queue with 8 more packets
    for (int i = 0; i < 8; i++) {
      p.offer(new Packet(i));
    }
    // check if size is 9
    assertEquals(Integer.valueOf(9), p.size());
    // queue that is full
    p.offer(new Packet(0));
    assertEquals(Integer.valueOf(10), p.size());
    // add another to test if 10 still
    p.offer(new Packet(0));
    assertEquals(Integer.valueOf(10), p.size());
  }



  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#add(edu.ics211.h08.Packet)}.
   */
  @Test
  void testAddPacket() {
    PacketQueue q = new PacketQueue();
    // check size 0
    assertEquals(0, q.size());
    // testing to see if it adds packet at 0
    assertTrue(q.add(new Packet(0)));
    // check size 1
    assertEquals(1, q.size());
    // loop to test still adding to size 9
    while (q.size() < 9) {
      assertTrue(q.add(new Packet(0)));
    }
    // test size 9
    assertEquals(9, q.size());
    // add to max queue
    assertTrue(q.add(new Packet(0)));
    assertEquals(10, q.size());
    try {
      q.add(new Packet(0));
      fail("didnt throw exception");
    } catch (IllegalStateException ise) {
      // expected
    }
  }


  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#offer(edu.ics211.h08.Packet)}.
   */
  @Test
  void testOffer() {
    PacketQueue q = new PacketQueue();
    // check size 0
    assertEquals(0, q.size());
    // testing to see if it offers packet at 0
    assertTrue(q.offer(new Packet(0)));
    // check size 1
    assertEquals(1, q.size());
    // loop to test still offering to size 9
    while (q.size() < 9) {
      assertTrue(q.offer(new Packet(0)));
    }
    // test size 9
    assertEquals(9, q.size());
    // offer to max queue
    assertTrue(q.offer(new Packet(0)));
    assertEquals(10, q.size());
    // check if it returns false if adding passed maxed queue
    assertFalse(q.offer(new Packet(0)));
  }


  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#remove()}.
   */
  @Test
  void testRemove() {
    PacketQueue q = new PacketQueue();
    // check size 0
    assertEquals(0, q.size());
    try {
      q.remove();
      fail("didnt throw exception");
    } catch (NoSuchElementException nse) {
      // expected
    }
    // loop to max queue
    while (q.size() < 10) {
      assertTrue(q.add(new Packet(0)));
    }
    // check if max
    assertEquals(10, q.size());
    q.remove();
    // check size 9
    assertEquals(9, q.size());
    // loop till 1 packet left
    while (q.size() != 1) {
      q.remove();
    }
    // test size 1
    assertEquals(1, q.size());
    // remove last packet
    q.remove();
    // check size 0
    assertEquals(0, q.size());
    
  }


  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#poll()}.
   */
  @Test
  void testPoll() {
    PacketQueue q = new PacketQueue();
    // check size 0
    assertEquals(0, q.size());
    assertNull(q.poll());
    // loop to max queue
    while (q.size() < 10) {
      assertTrue(q.add(new Packet(0)));
    }
    // check if max
    assertEquals(10, q.size());
    q.poll();
    // check size 9
    assertEquals(9, q.size());
    // loop till 1 packet left
    while (q.size() != 1) {
      q.poll();
    }
    // test size 1
    assertEquals(1, q.size());
    // poll last packet
    q.poll();
    // check size 0
    assertEquals(0, q.size());
  }


  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#element()}.
   */
  @Test
  void testElement() {
    PacketQueue q = new PacketQueue();
    // check size 0
    assertEquals(0, q.size());
    // fill queue
    for (int i = 0; i < 10; i++) {
      q.add(new Packet(i));
    }
    // test size 10
    assertEquals(10, q.size());
    // check if first packet is address with 0
    assertEquals(0, q.element().getAddress());
    // loop till 1 packet left
    while (q.size() != 1) {
      q.poll();
    }
    // check if next packet in queue is 9
    assertEquals(9, q.element().getAddress());
    // remove last packet
    q.poll();
    try {
      q.element();
      fail("didnt throw exception");
    } catch (NoSuchElementException nse) {
      // expected
    }
  }


  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#peek()}.
   */
  @Test
  void testPeek() {
    PacketQueue q = new PacketQueue();
    // check size 0
    assertEquals(0, q.size());
    // fill queue
    for (int i = 0; i < 10; i++) {
      q.add(new Packet(i));
    }
    // test size 10
    assertEquals(10, q.size());
    // check if first packet is address with 0
    assertEquals(0, q.peek().getAddress());
    // loop till 1 packet left
    while (q.size() != 1) {
      q.poll();
    }
    // check if next packet in queue is 9
    assertEquals(9, q.peek().getAddress());
    // remove last packet
    q.poll();
    assertNull(q.peek());
  }


  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#iterator()}.
   */
  @Test
  void testIterator() {
    PacketQueue q = new PacketQueue();
    // fill queue
    for (int i = 0; i < 10; i++) {
      q.add(new Packet(i));
    }
    // removing 2 packets 
    q.remove();
    q.remove();
    // add new packet
    q.add(new Packet(10));
    System.out.println("This is for the iterator test: \n");
    // making an Iterator Packet
    java.util.Iterator<Packet> i = q.iterator();
    // loop as it has next element
    while (i.hasNext()) {
      // iterate through elements
      Packet p = i.next();
      System.out.println(p);
    }
  }


  /**
   * Test method for {@link edu.ics211.h08.PacketQueue#toString()}.
   */
  @Test
  void testToString() {
    PacketQueue q = new PacketQueue();
    // check size 0
    assertEquals(0, q.size());
    System.out.println(q.toString() + "\n");
    // add packet
    q.add(new Packet(0));
    System.out.println(q.toString() + "\n");
    // fill till 9 packets
    while (q.size() < 9) {
      q.add(new Packet(9));
    }
    System.out.println(q.toString() + "\n");
    // fill last spot in queue
    q.add(new Packet(10));
    System.out.println(q.toString() + "\n");
    
    assertTrue(q.toString() != null);
  }

}
