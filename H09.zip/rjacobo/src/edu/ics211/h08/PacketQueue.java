package edu.ics211.h08;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;

/**This is my code.
 * @author Ruben Jacobo
 *
 */
public class PacketQueue extends AbstractQueue<Packet> implements Queue<Packet> {

  private Packet[] packets;
  private int front;
  private int rear;
  private int size;
 
  
  
  /**
  * Creates a new PacketQueue.
  */
  public PacketQueue() {
    //initialize all
    this.packets = new Packet[10];
    this.front = 0;
    this.rear = 0;
    this.size = 0;
  }
  
  
  @Override
  public boolean offer(Packet e) {
    if (size == 10) {
      //return false if full
      return false;
    }
    //if not full, add e to the end
    packets[rear] = e;
    rear = (rear + 1) % packets.length;
    size++;
    //incrememnt size and return true
    return true;
  }

  @Override
  public boolean add(Packet e) {
    if (size == packets.length) {
      throw new IllegalStateException();
      //throw exception if full
    }
    //add e at the back, same as offer
    packets[rear] = e;
    rear = (rear + 1) % packets.length;
    size++;
    //incrememnt size and return true
    return true;
  }

  @Override
  public Packet poll() {
    if (size == 0) {
      return null;
      //return null if its empty
    }
    Packet rem = packets[front];
    //remember the packet at the front
    front = (front + 1) % packets.length;
    // update what is in the front
    size--;
    //decrement size and return remembered packet
    return rem;
  }
  
  @Override
  public Packet remove() {   
    if (size == 0) {
      throw new NoSuchElementException();
      //throw exception if empty
    }
    Packet rem = packets[front];
    front = (front + 1) % packets.length;
    //update front
    size--;
    //decrement size and return remembered packet
    return rem;
  }
  

  @Override
  public Packet peek() {
    try {
      //try catch to catch the exception
      return element();
    } catch (NoSuchElementException nse) {
      return null;
      //if exception is caught, return null instead
    }
  }
  
  @Override
  public Packet element() {
    if (size == 0) {
      //if empty, throw no such element exception
      throw new NoSuchElementException();
    }
    //else return the packet at the front
    return packets[front];
  }


  @Override
  public Iterator<Packet> iterator() {
    // TODO Auto-generated method stub
    return new MyIterator();
    //return an instance of myIterator
  }
  
  private class MyIterator implements Iterator<Packet> {
    private int nextIndex;
    
    public MyIterator() {
      //initialize nextIndex to front
      nextIndex = front;
    }

    @Override
    public boolean hasNext() {
      // make sure nextIndex is not equal to rear
      return nextIndex != rear;
    }

    @Override
    public Packet next() {
      if (hasNext()) {
        //make sure theres somethign there first
        Packet pack = packets[nextIndex];
        //new variable pack, stores whats in the array at index NextIndex
        nextIndex = (nextIndex + 1) % packets.length;
        //update nextIndex
        return pack;
        //return remembered value
      } else {
        throw new NoSuchElementException();
        //or else jus tthrow exception
      }

    }

  

    @Override
    public String toString() {
        
      int counter = 0;
      // new variable to count
      int frun = front;
      while (counter != size) {
        //while loop print out in string form whatever is at that index "frun"
        System.out.println(packets[frun].toString());
        frun = (frun + 1) % packets.length;
        //update frun and incremment the counter
        counter++;
      }
      return "Done";
      //return string DOne to indicate that we done
    }
  } 


  @Override
  public int size() {
    // return int size
    return size;
  }

}
