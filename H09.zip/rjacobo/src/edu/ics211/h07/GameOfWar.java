package edu.ics211.h07;

public class GameOfWar implements IGameOfWar {
  
  private Stack<Card> playerOne;
  private Stack<Card> playerTwo;
  
  /**Game of war constructor.
   * initialize player one and two's decks
   */
  public GameOfWar() {
    playerOne = new Stack<Card>();
    playerTwo = new Stack<Card>();
    //create new stacks for each player to hold their cards
    
  }

  @Override
  public void initializeGame(Deck d) {
    while (d.size() > 1) {
      //keep looping while the deck has 2 or more cards in it
      playerOne.push(d.dealACard());
      playerTwo.push(d.dealACard());
      //add cards into each players decks

    }
    
  }

  @Override
  public boolean playARound() {
    Stack<Card> decker = new Stack<Card>();
    //create a new stack to hold the cards for the winner of this round
    Card p1Card = playerOne.pop();
    Card p2Card = playerTwo.pop();
    //pop a card off each players stacks
    
    decker.push(p1Card);
    decker.push(p2Card);
    //add the cards to the round deck
    
    if (p1Card.getRank().compareTo(p2Card.getRank()) > 0) {
      playerOne = combineStacks(playerOne, decker);  
      //if player1 has the better card, player1 wins this round and this deck
    } else 
      
      if (p1Card.getRank().compareTo(p2Card.getRank()) < 0) {
        playerTwo = combineStacks(playerTwo, decker);
        // if player2 has the better card, player2 wins this round and this deck
       
      } else {
        //if its a tie, war begins
        while (playerOne.empty() == false && playerTwo.empty() == false) {
          //keep looping while both players still have cards
          decker.push(playerOne.pop());
          decker.push(playerTwo.pop());
          //pop card form each player and add to the pot directly
       
       
          p1Card = playerOne.pop();
          p2Card = playerTwo.pop();
          //pop another card (this time facing up) from each player and add to the pot
          decker.push(p1Card);
          decker.push(p2Card);
         
          //player with the better card wins the pot, if tie, loop again until winner is found
          if (p1Card.getRank().compareTo(p2Card.getRank()) > 0) {
            playerOne = combineStacks(playerOne, decker);
            break;
          }
       
          if (p1Card.getRank().compareTo(p2Card.getRank()) > 0) {
            playerOne = combineStacks(playerOne, decker);
            break;
          }   
       
        }

      }
    //boolean method, return true once either of the players have an empty deck
    return (playerOne.empty() || playerTwo.empty());
  }

  @Override
  public Stack<Card> playerOnesCards() {
    // return first players stack of cards
    return playerOne;
  }

  @Override
  public Stack<Card> playerTwosCards() {
    // return playerTwo's stack of cards
    return playerTwo;
  }

  @Override
  public Stack<Card> combineStacks(Stack<Card> top, Stack<Card> bottom) {
    // reverse top and bottom
    Stack<Card> combined = new Stack<Card>();
    // create new stack to hold things in
    while (!(top.empty())) {   
      //keep pushing contents of top into temporary stack
      combined.push(top.pop());
    }
    
    while (!(combined.empty())) {
      // push the contents of the combined stack into the bottom stack
      bottom.push(combined.pop());
    }
    
    // return bottom
    return bottom;
  }

}
