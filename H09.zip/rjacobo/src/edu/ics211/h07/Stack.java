package edu.ics211.h07;

import java.util.Arrays;
import java.util.EmptyStackException;

/**Implementation of the Stack methods with array.
 * @author Ruben Jacobo
 *     assisted by Gavin Peng
 */
public class Stack<E> implements IStack211<E> {

  private E[] stack; 
  private int size;  
  
  
  /**Stack constructor initialize stuff.
   * 
   */
  @SuppressWarnings("unchecked")
  public Stack() {
    //initialize size and array stack
    stack = (E[]) new Object[52];
    size = 0;
    
  }
  
  public boolean empty() { 
    return size == 0;
  }

  
  /** push method.
  * pushes the item onto the stack 
  */
  public E push(E item) {
    //if the size is the same as the length of the stack
    if (size == stack.length) {
      //increase the length of the array to hold more numbers
      stack = Arrays.copyOf(stack, 2 * stack.length);
    }
    //store the item in the array slot
    stack[size++] = item;
    //return the item
    return item;
  }

  /** peek method.
   * looks at item on top of stack 
   */
  public E peek() {
    //if empty throw exception
    if (empty()) {
      throw new EmptyStackException();
    }
    //return the top element in the stack
    return stack[size - 1];
  }

  /** pop method.
   *  pops top of stack and returns it
   */
  public E pop() {
    //check if the array is empty
    if (empty()) {
      //thrown empty stack exception
      throw new EmptyStackException();
    }
    //remove last thing in array 
    //return the removed element
    return stack[--size];
  }

}
