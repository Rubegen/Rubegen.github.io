package edu.ics211.h07;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;


class StackTest {
  
  public Stack<Integer> num = new Stack<Integer>();
  

  @Test
  void testStack() {
    assertTrue(num.empty());
  }


  @Test
  void testEmpty() {
    //make sure it marks it as empty when empty
    assertTrue(num.empty());
    //add to the stack and test if it is marked as empty
    num.push(2);
    assertFalse(num.empty());
  }


  @Test
  void testPush() {
    //push a bunch of numbers
    num.push(1);
    num.push(2);
    num.push(3);
    assertEquals(Integer.valueOf(3), num.peek());
    //use peek to ensure that the numbers are being pushed correctly
    num.push(4);
    assertEquals(Integer.valueOf(4), num.peek());
    //int 4 should be on top, push is working correctly
  }


  @Test
  void testPeek() {
    num.push(4);
    //push a number on the stack
    assertEquals(Integer.valueOf(4), num.peek());
    //peek should read the value 4 if functioning properly
    num.push(7);
    assertEquals(Integer.valueOf(7), num.peek());
    //peek should now read the value 7
  }


  @Test
  void testPop() {
    num.push(5);
    assertEquals(Integer.valueOf(5), num.pop());
    assertTrue(num.empty());
    
  }

}
