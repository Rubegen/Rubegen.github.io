package edu.ics211.h09;

public class MySudokuTest {

  /** Main method to test my code.
   * 
   * @param args arguments of string.
   */
  public static void main(String[] args) {
    int [][] solution = {
        {7, 6, 5, 9, 4, 8, 2, 1, 3},
        {1, 2, 4, 5, 3, 6, 7, 8, 9}, 
        {8, 9, 3, 7, 2, 1, 4, 5, 6},
        {2, 4, 7, 1, 6, 3, 5, 9, 8},
        {9, 3, 6, 2, 8, 5, 1, 7, 4},
        {5, 8, 1, 4, 7, 9, 3, 6, 2},
        {3, 7, 8, 6, 1, 4, 9, 2, 5},
        {4, 5, 2, 8, 9, 7, 6, 3, 1},
        {6, 1, 9, 3, 5, 2, 8, 4, 7} };
 
    if (Sudoku.solveSudoku(solution)) {
      System.out.println("solution is correct");
    }
    
    //same as solution but first number changed from 7-6
    int[][] solution2 = {
        {6, 6, 5, 9, 4, 8, 2, 1, 3},
        {1, 2, 4, 5, 3, 6, 7, 8, 9}, 
        {8, 9, 3, 7, 2, 1, 4, 5, 6},
        {2, 4, 7, 1, 6, 3, 5, 9, 8},
        {9, 3, 6, 2, 8, 5, 1, 7, 4},
        {5, 8, 1, 4, 7, 9, 3, 6, 2},
        {3, 7, 8, 6, 1, 4, 9, 2, 5},
        {4, 5, 2, 8, 9, 7, 6, 3, 1},
        {6, 1, 9, 3, 5, 2, 8, 4, 7} };
    
    //value at 0,0 should be 7 not 6
    
    
    if (Sudoku.solveSudoku(solution2)) {
      System.out.println("Solution2 is correct");
    } else {
      System.out.println("solution2 is incorrect, as expected");
    }
    
    //copy of previous
    //changed the first value to zero to test legalValues method
    
    int[][] solution3 = {
        {0, 6, 5, 9, 4, 8, 2, 1, 3},
        {1, 2, 4, 5, 3, 6, 7, 8, 9}, 
        {8, 9, 3, 7, 2, 1, 4, 5, 6},
        {2, 4, 7, 1, 6, 3, 5, 9, 8},
        {9, 3, 6, 2, 8, 5, 1, 7, 4},
        {5, 8, 1, 4, 7, 9, 3, 6, 2},
        {3, 7, 8, 6, 1, 4, 9, 2, 5},
        {4, 5, 2, 8, 9, 7, 6, 3, 1},
        {6, 1, 9, 3, 5, 2, 8, 4, 7} };
    
    System.out.println("Checking legal values of position (0,0)");
    
    if (Sudoku.legalValues(solution3, 0, 0).get(0) == 7) {
      System.out.println("Correct legal value found: 7");
    } else {
      System.out.println("Incorrect legal value found, expected was 7");
    }
    
    //value of position (0,1) should be null
    System.out.println("Checking legal values of position (0,1)");
    //should return null because cell already filled
    if (Sudoku.legalValues(solution3, 0, 1) == null) {
      System.out.println("No legal values available, correct");
    } else {
      System.out.println("Did not return null, incorrect");
    }
    
    //copy 2D array from sudoku test
    int[][] example = { 
        { 7, 8, 0, 0, 9, 0, 0, 2, 0 }, 
        { 1, 0, 0, 0, 0, 0, 9, 6, 4 },
        { 0, 0, 0, 2, 5, 1, 0, 0, 0 },
        { 0, 0, 6, 1, 8, 5, 0, 0, 0 },
        { 5, 0, 4, 0, 0, 0, 3, 0, 2 },
        { 0, 0, 0, 3, 4, 2, 5, 0, 0 },
        { 0, 0, 0, 9, 6, 3, 0, 0, 0 },
        { 6, 4, 1, 0, 0, 0, 0, 0, 3 },
        { 0, 9, 0, 0, 1, 0, 0, 5, 7 } };
    
    // called solveSudoku to get rid of the zeros
    if (Sudoku.solveSudoku(example)) {
      for (int i = 0; i < example.length; i++) {
        for (int j = 0; j < example.length; j++) {
          if (example[i][j] == 0) {
            System.out.println("Empty cell found");
          }
        }
      }
      
      System.out.println(Sudoku.toString(example, true));
    }
  }
  
}
