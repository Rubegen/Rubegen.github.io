/**
 * 
 */
package edu.ics211.h01;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author Ruben Jacobo
 * assisted by Gavin, Louie;
 *
 */
public class Translator implements Translate {

  /**
   * 
   */
  public Translator() {
    // TODO Auto-generated constructor stub
  }


  @Override
  public String asBinaryString(InputStream in) { 
    try {
        BitReader read = new BitReader(in);
       //create bitreader from input stream;
        StringBuilder bild = new StringBuilder();
       //create string builder 
        while(!read.isDone()) {
          //loop until bitreader is done
          if(read.readAsInt()==1) {
           //append 0 or 1 from bitreader to stringbuilder
            bild.append(1);}
            else { 
              bild.append(0);
            }
         
        }
         read.close();
         //return stringbuilder.toString
         return bild.toString();
      } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
     
    return null;
  }


  @Override
  public String asHexadecimalString(InputStream in) {
    // TODO Auto-generated method stub
    StringBuilder sbd = new StringBuilder();
    //create a String builder
      try {
        while(in.available()>0) {
          //loop until the input stream is done
         
          if(!(sbd.length()%2==0)) {
            sbd.insert(sbd.length() - 1, 0);
          }
          sbd.append(Integer.toHexString(in.read()));
          //append if there is remainder
        }
        return sbd.toString();
        //return stringbuilder.toString
      } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
     
    
    return null;
  }


  @Override
  public String asUtf8String(InputStream in) {
    // TODO Auto-generated method stub
    try {
      byte [] bits = new byte[in.available()];
      //create an array of bytes
      for(int i=0; i<in.available(); i++) {
        in.read(bits);
        //fill the array from input stream
      }
      return new String(bits, "UTF-8"); 
      //return the newly constructed String
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return null;
  }

}
