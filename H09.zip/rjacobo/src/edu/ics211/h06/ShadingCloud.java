package edu.ics211.h06;


import edu.ics211.h02.Cloud;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;



public class ShadingCloud implements ICloudShading {
  
  private Cloud[] cloudList;
  
  public ShadingCloud(Cloud [] skyClouds) {
    cloudList = skyClouds;
    
  }

  @Override
  public List<Cloud> shadingClouds(int startAltitude) {
    // create CloudList
    SortableList<Cloud> cloudBlower = new SortableList<Cloud>();
    // add the clouds from clouds[] into cloudList
    for (int i = 0; i < cloudList.length; i++) {
      cloudBlower.add(i, cloudList[i]);
    }
    Iterator<Cloud> cloudIter = cloudBlower.iterator(new CloudComparator());
    // create empty ArrayList of type cloud
    List<Cloud> cloudShader = new ArrayList<Cloud>();
    while (cloudIter.hasNext()) {
      //iterates through the list using element
      Cloud cloud = cloudIter.next();
      if (cloud.getAltitude() >= startAltitude) {
        // if altitude is greater or equal to startAltitude, add to list
        cloudShader.add(cloud);
      }
    }
 
 
    // return list
    return cloudShader;
  }
  
  public class CloudComparator implements Comparator<Cloud> {
    //compare the altitudes with this comparator class
    public int compare(Cloud cloud1, Cloud cloud2) {
      return cloud1.getAltitude().compareTo(cloud2.getAltitude());
    }

  }
}
