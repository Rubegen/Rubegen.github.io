package edu.ics211.h06;

import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import edu.ics211.h04.IList211;
import edu.ics211.h05.SortableList.DLinkedNode;

/**This is my code.
 * @author Ruben Jacobo
 *
 */
public class SortableList<E> implements IList211<E>, Iterable<E> {

  private DLinkedNode tail;
  private int size;
  
  
  @Override
  public E get(int index) {
    checkIndex(index);
    
    DLinkedNode temp = tail;
    // temporary variable to traverse down, starting at tail
    for (int i = size - 1; i > index; i--) {
      //temp goes down the list after every loop
      temp = temp.prev;
      //when i becomes equal to index, break loop
    }
    //return the item at temp 
    return temp.item;
  }


  @Override
  public E set(int index, E element) {
    checkIndex(index);
    //check validity of index
    DLinkedNode temp = tail;
    //temporary variable to keep track of tail
    for (int i = size - 1; i > index; i--) {
      temp = temp.prev;
      //travers down the list
    }
    //keep track of the old value
    E oldVal = temp.item;
    //replace the item at temp with element
    temp.item = element;
    return oldVal; 
    //return the oldVal
  }


  @Override
  public int indexOf(Object obj) {
    int index = 0;
    for (int i = size - 1; i >= 0; i--) {
      E tester = get(i);
      //get the item at i
      if (obj == tester) {
        //compare the item to the object were looking for
        index = i;
        return index;
        //if a match is found, return the index it was found at
      }
    }
    //if not match was found, return -1
    return -1;
  }


  @Override
  public int size() {
    // TODO Auto-generated method stub
    return size;
  }


  @Override
  public boolean add(E e) {
    //call the other add method and place e at the end of the list
    add(size, e);
    return true;
    //return true when done
  }


  @Override
  public void add(int index, E element) {
    // Check if index is valid
    if (index < 0 || index > size) {
      throw new IndexOutOfBoundsException();
    }
    DLinkedNode temp = tail;
    // Creating a newNode to add
    DLinkedNode newNode = new DLinkedNode(element, null, tail);
    if (size == 0) {
      tail = newNode;
    }
    // if index is equal to size
    if (index == size) {
      // tail is pointing to the newNode
      tail.next = newNode;
      // newNode is pointing to tail
      newNode.prev = tail;
      tail = newNode;
    } else {
      for (int i = size - 1; i >= 0; i--) {
        // if index is not equal to size
        if (i == index) {
          // assigning the new tail
          newNode.next = temp;
          // puts this in the old tail's position
          newNode.prev = temp.prev;
          // take the new tail and put this node behind it
          temp.prev = newNode;
          // 2 steps back and 1 step forward
          temp.prev.prev.next = newNode;
        }
        temp = temp.prev;
      }
    }
    size++;
  
  }


  @Override
  public E remove(int index) {
    DLinkedNode temp = tail;
    // set the temp to tail
    checkIndex(index);
    for (int i = size - 1; i > index; i--) {
      temp = temp.prev; 
      //traverse from the tail of the list, to the given index
    }
    if (index == size - 1) {
      //if given index is the last item in the list
      if (temp.prev != null) {
        //make sure the previous item is not null first
        temp.prev.next = temp.next;
        // point things to the right place
        tail = temp.next;
      }
    
    } else {
      if (temp.prev != null) {
        //make sure the prev is not null
        temp.prev.next = temp.next;
        //reassign the values to point to the correct place
      }
      if (temp.next != null) {
        //make sure temp.next is not null
        temp.next.prev = temp.prev;
        //point it to the right place
      }
    }
    size--;
    //decrement size and return the removed item
    return temp.item;
  }
  
  private void checkIndex(int index) {
    if (index < 0 || index >= size) {
      throw new IndexOutOfBoundsException();
      //throw an exception if the index given is out of bounds
    }
  }


  @Override
  public Iterator<E> iterator() {
    
    return new MyIterator();
  }
  
  public Iterator<E> iterator(Comparator<E> c) {
    
    return new MyListIterator(c);
  }
  
  private DLinkedNode traverse(int index) {
    checkIndex(index);
    
    DLinkedNode temp = tail;
    // temporary variable to traverse down, starting at tail
    for (int i = size - 1; i > index; i--) {
      //temp goes down the list after every loop
      temp = temp.prev;
      //when i becomes equal to index, break loop
    }
    //return the item at temp 
    return temp;
  }
  
  private class DLinkedNode {
    E item;
    DLinkedNode next;
    DLinkedNode prev;
    
  
    public DLinkedNode(E item, DLinkedNode next, DLinkedNode prev) {
      this.item = item;
      this.next = next;
      this.prev = prev;
    }
  }
  
  private class MyIterator implements ListIterator<E> {
    
    private DLinkedNode nextNode;
    private int nextIndex;
    
    
    public MyIterator() {
      nextIndex = 0;
      nextNode = traverse(0);
    }
    

    @Override
    public boolean hasNext() {
      return nextIndex < size;
    }

    @Override
    public E next() {
      if (nextIndex >= size)  {
        throw new NoSuchElementException();
      }
      //remember the value under nextNode variable
      DLinkedNode temp = nextNode;
      nextNode = nextNode.next;
      //update nextNode to point to the following node
      nextIndex++;
      //increment the nextIndex
      return temp.item;
      //return remembered item
         
    }

    @Override
    public boolean hasPrevious() {
      return nextIndex > 0;
    }

    @Override
    public E previous() {
      if (nextIndex == 0) {
        throw new NoSuchElementException();
      }
      DLinkedNode temp = nextNode.prev;
      nextNode = nextNode.prev;
      nextIndex--;
      return temp.item;
    }

    @Override
    public int nextIndex() {
      // return nextIndex
      return nextIndex;
    }

    @Override
    public int previousIndex() {
      // index before nextIndex variable
      return nextIndex - 1;
    }

    @Override
    public void remove() {
      throw new UnsupportedOperationException();
      //unsupported methods
    }

    @Override
    public void set(E e) {
      throw new UnsupportedOperationException();
      
    }

    @Override
    public void add(E e) {
      throw new UnsupportedOperationException();
      
    }
    
  }
  
  private class MyListIterator implements Iterator<E> {
      
    private int index;
    private DLinkedNode node;
    private SortableList<E> copyList;

      
    public MyListIterator(Comparator<E> c) {
      copyList = new SortableList<E>();
      //make a new SortableList
      copyElements();
      //call the copyElements method to copy the list
      selectionSort(c);
      //sort it by selection sort
      index = 0;
      node = getNodeAtIndex(index);
      //method to get node at the specified index
    }
      
    private DLinkedNode getNodeAtIndex(int index) {
      checkIndex(index);
        
      DLinkedNode current = tail;
      for (int i = size - 1; i >= index; i--) {
        if (i == index) {
          return current;
        }
        current = current.prev;
      }
         
      return current;
    }
      
    private void copyElements() {
      DLinkedNode temp = tail;
      //keep track of the tail with variable temp 
      for  (int i = 0; i < size; i++) {
        //copy elements from the list into the copy
        copyList.add(i, temp.item);
      }
      temp = temp.prev;
    }

    public void selectionSort(Comparator<E> c) {
      // loop from 0 to data.length - 1
      for (int i = 0; i < size - 1; i++) {
        // Set current minimum value to i-0;
        int posMin = i;
        // Loops through the array 1 ahead of i
        for (int j = i + 1; j < size; j++) {
          // Compare the elements in the inner loop with the element
          if (c.compare(get(j), get(posMin)) < 0) {
            // Set new current minimum value
            posMin = j;
          }
        }
        // Swap the minimum element with current element
        if (i != posMin) {
          E temp = get(i);
          //data[i] = data[posMin];
          set(i, get(posMin));
          //data[posMin] = temp;
          set(posMin, temp);
        }
      }
        
        
    }

    @Override
    public boolean hasNext() {
      //will return false if index out of bounds
      return index < size;
    }

    @Override
    public E next() {
      if (index >= size)  {
        //throw exception in this case
        throw new NoSuchElementException();
      }
      DLinkedNode temp = node;
      //keep track of this node
      node = node.next;
      index++;
      //increment index
      return temp.item;
      //return temp
    }
      
  }
    
  

}
