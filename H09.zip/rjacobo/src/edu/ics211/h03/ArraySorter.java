package edu.ics211.h03;

import java.util.Comparator;

/** This is my code.
 * @author Ruben Jacobo
 *     assisted by Gavin Peng
 *     
 *
 */
public class ArraySorter<E> implements SortsArray<E> {
  
  long time;
  

  /** This is my code.
   * 
   */
  public ArraySorter() {
    // TODO Auto-generated constructor stub
  }

  @Override
  //found this at https://www.geeksforgeeks.org/insertion-sort/
  public void insertionSort(Comparator<E> compare, SortRecord<E>[] data) {
    
    long start = System.nanoTime();
    for (int i = 1; i < data.length; i++) {
     
      SortRecord<E> key = data[i]; 
      int j = i - 1; 
      //j is the position before i
      data[i].numberOfComparisons++;
      //increment comparisons
      while (j >= 0 && compare.compare(data[j].element, key.element) > 0) { 
        data[i].numberOfSwaps++;
        //swap pos ahead of j with j
        data[j + 1] = data[j]; 
        j = j - 1; 
      } 
      data[j + 1] = key; 
    } 
      
    
    long end = System.nanoTime();
    //take the difference between end and start to find elapsed time
    time = end - start;
    
    
  }

  @Override
  //found this at https://www.geeksforgeeks.org/java-program-for-bubble-sort/
  public void bubbleSort(Comparator<E> compare, SortRecord<E>[] data) {
    // TODO Auto-generated method stub
    long start = System.nanoTime();
    //note the start time
    int n = data.length;
    //data length is variable n
    for (int i = 0; i < n - 1; i++) {
      //inner for loop
      for (int j = 0; j < n - i - 1; j++) {
        data[i].numberOfComparisons++;  
        if (compare.compare(data[j].element, data[j + 1].element) > 0) {
          data[i].numberOfSwaps++;
          // swap j and one above j
          data[j] = data[j + 1];
    
        }
      }
    }

    //keep track of time elapsed
    long end = System.nanoTime();
    time = end - start;
    
  }

  @Override
  //found this at https://www.geeksforgeeks.org/java-program-for-selection-sort/
  public void selectionSort(Comparator<E> compare, SortRecord<E>[] data) {
    // TODO Auto-generated method stub
    long start = System.nanoTime();
    int n = data.length;
    int pos;
    
    // loop through array
    for (int i = 0; i < n - 1; i++) {
      pos = i;
      // Find the minimum element in unsorted array
      for (int j = i + 1; j < n - i - 1; j++) {
        int mindex = i;
        // add to number of comparisons
        data[i].numberOfComparisons++;
        if (compare.compare(data[j].element, data[mindex].element) > 0) {
          data[i].numberOfSwaps++;
          mindex = j;
          //set min to j
          
        }
        
      }
        
      
      // Swap the found minimum element with the first
      // element
     
      SortRecord<E> temp = data[pos];
      data[i + 1] = data[i];
      data[i] = temp; 
      
    }
      
    
    //keep track of time elapsed
    long end = System.nanoTime();
    time = end - start;
    
  }

  @Override
  public double getSortTime() {
    // return elapsed time
    return time;
  }

}
