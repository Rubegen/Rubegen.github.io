package edu.ics211.h03;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class ReadFile implements IReadFile {

  public ReadFile() {
    // TODO Auto-generated constructor stub
  }

  @Override
  public String readFile(String fileName) throws IOException {
    // DataInputStream from FileInputStream
    // FileInputStream through fileName
    FileInputStream fileInput = new FileInputStream(fileName);
    DataInputStream data = new DataInputStream(fileInput);
    //read in number of bytes
    int readByte = data.readInt();
    //read in the encoding
    byte encoding = data.readByte();
    //create array of bytes as long as data stream
    byte[] dataByte = new byte[readByte];
    //loop to fill each index of array
    for (int i = 0; i < dataByte.length; i++) {
      dataByte[i] = data.readByte();
      
    }
    
    switch (encoding) {
      case 1: 
        // return new String ASCII
        return new String(dataByte, "ASCII");
      case 2: 
        //return new String UTF_16LE
        return new String(dataByte, "UTF_16LE");
      case 3: 
        //return new String UTF-8
        return new String(dataByte, "UTF-8");
      case 4: 
        //return new String UTF-16
        return new String(dataByte, "UTF-16");
      default:
        //throw exception
        throw new IOException();
    }
    
  }

}
