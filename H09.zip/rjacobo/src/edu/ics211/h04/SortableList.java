package edu.ics211.h04;

import edu.ics211.h03.SortRecord;
import java.util.Comparator;



/**This is my code.
 * @author Ruben Jacobo
 * Assisted by Gavin, Louie
 * 
 */
public class SortableList<E> implements ISortableList<E>, IList211<E> {
  private E[] data;
  private int size;
  private int numberOfSwaps;
  private int numberOfComparisons;
  private double sortTime;
  /**This is my code.
   * 
   */
  
  public SortableList() {
    data = ((E[]) new Object[10]);
    size = 0;
    numberOfSwaps = 0;
    numberOfComparisons = 0;
    sortTime = 0;
    // TODO Auto-generated constructor stub
  }
  
  long time;
  
  private void checkIndex(int index) {
    if (index < 0 || index >= size) {
      throw new IndexOutOfBoundsException();
      //throw an exception if the index given is out of bounds
    }
  }

  @Override
  public E get(int index) {
    checkIndex(index);
    //check if index given is bad
    return data[index];
    //return object at this index
  }

  @Override
  public E set(int index, E element) {
    checkIndex(index);
    //check index to see if bad
    E temp = data[index];
    //remember old value
    data[index] = element;
    //set the information at index to element
    return temp;
    //return old value
  }

  @Override
  public int indexOf(Object obj) {
    
    for (int i = 0; i < size(); i++) {
      if (data[i].equals(obj)) {
        return i;
      }
    }
    return -1;
  }

  @Override
  public int size() {
    
    return this.size;
  }

  @Override
  public boolean add(E e) {
    // if capacity is at its limit, then double the capacity
    if (size == data.length - 1) {
    
      E[] copyData = (E[]) new Object[data.length * 2];
      
      // copy over to new capacity
      for (int i = 0; i < data.length; i++) {
        copyData[i] = data[i];
      }
      data = copyData;
    }
    data[size++] = e;
    return true;
  }

  @Override
  public void add(int index, E element) {
    // check the index
    if (index < 0 || index > size) {
      throw new IndexOutOfBoundsException(index);
    }
    // if capacity is at its limit, then double the capacity
    if (size == data.length - 1) {
      
      E[] copyData = (E[]) new Object[data.length * 2];
      for (int i = 0; i < data.length; i++) {
        copyData[i] = data[i];
      }
      data = copyData;
    }
    // shift data in elements from index to size - 1
    for (int i = size; i >= index; i--) {
      data[i + 1] = data[i];
    }
    //insert new item
    data[index] = element;
    size++;
  }

  @Override
  public E remove(int index) {
    checkIndex(index);
    //check if index is dumb
    E temp = data[index]; 
    //save old value in temp
    for (int i = index + 1; i < size(); i++) {
      data[i - 1] = data[i];
    }
    size--;
    //size of the list shrinks by one
    return temp;
  }

  @Override
  public void insertionSort(Comparator<E> compare) {
    // reset swaps and comparisons
    numberOfSwaps = 0;
    numberOfComparisons = 0;
    // get start time
    final long startTime = System.nanoTime();
    boolean swapped;
    // loops from 1 to data.length - 1
    for (int i = 1; i < size; i++) {
      swapped = false;
      // remember the item at 1
      E key = data[i];
      int j = i;
      // while the hole isn't at 0 and the thing to the left of the hole is greater than remembered
      while (j > 0 && compare.compare(data[j - 1], key) > 0) {
        this.numberOfComparisons++;
        // swap the elements
        data[j] = data[j - 1];
        this.numberOfSwaps++;
        swapped = true;
        j--;
      }
      if (j != 0) {
        numberOfComparisons++;
      }
      if (swapped) {
        data[j] = key;
      }

    }

    // get end time
    long endTime = System.nanoTime();
    // calculates sorting time by end time minus start time
    sortTime = endTime - startTime;
  }

  @Override
  public void bubbleSort(Comparator<E> compare) {
    // reset swaps and comparisons
    numberOfSwaps = 0;
    numberOfComparisons = 0;
    // get start time
    final long startTime = System.nanoTime();

    boolean sort;
    do {
      // there are no more sorts
      sort = false;
      // loop through the length of the array
      for (int i = 0; i < size - 1 - this.numberOfSwaps; i++) {
        // count # of comparisons
        this.numberOfComparisons++;
        // compare data[i] and data[i + 1] if > 0 swap and count swap
        if (compare.compare(data[i], data[i + 1]) > 0) {
          // swap the elements
          E temp = data[i];
          data[i] = data[i + 1];
          data[i + 1] = temp;
          // sorting still happening
          sort = true;
          // count # of swaps
          this.numberOfSwaps++;
        }
      }
    } while (sort);
    // get end time
    long endTime = System.nanoTime();
    // calculates sorting time by end time minus start time
    sortTime = endTime - startTime;
    
  }

  @Override
  public void selectionSort(Comparator<E> compare) {
    // reset swaps and comparisons
    numberOfSwaps = 0;
    numberOfComparisons = 0;
    // get start time
    final long startTime = System.nanoTime();

    // loop from 0 to data.length - 1
    for (int i = 0; i < size - 1; i++) {
      // Set current minimum value to i-0;
      int posMin = i;
      // Loops through the array 1 ahead of i
      for (int j = i + 1; j < size; j++) {
        // count # of comparisons
        this.numberOfComparisons++;
        // Compare the elements in the inner loop with the element
        if (compare.compare(data[j], data[posMin]) < 0) {
          // Set new current minimum value
          posMin = j;
        }
      }

      // Swap the minimum element with current element
      if (i != posMin) {
        E temp = data[i];
        data[i] = data[posMin];
        data[posMin] = temp;
        // count # of swaps
        numberOfSwaps++;
      }
    }
    // get end time
    long endTime = System.nanoTime();
    // calculates sorting time by end time minus start time
    sortTime = endTime - startTime;
  }

  @Override
  public int getNumberOfSwaps() {
    //return swaps
    return numberOfSwaps;
  }

  @Override
  public int getNumberOfComparisons() {
    // return comparisons
    return numberOfComparisons;
  }

  @Override
  public double getSortTime() {
    // return time to sort
    return sortTime;
  }

}
