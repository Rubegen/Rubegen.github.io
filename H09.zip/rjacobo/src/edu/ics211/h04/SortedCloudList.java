package edu.ics211.h04;

import edu.ics211.h02.Cloud;
import java.util.Comparator;



public class SortedCloudList<E> implements IList211<Cloud> {
  
  private SortableList<Cloud> list;
  private Comparator<Cloud> compare;
  
  
  SortedCloudList(Comparator<Cloud> compare) {
    list = new SortableList<Cloud>();
    this.compare = compare;
    //set comparator from this class to compare
  }

  @Override
  public Cloud get(int index) {
    //return the thing at index from list   
    return list.get(index);
    
  }

  @Override
  public Cloud set(int index, Cloud element) {
    Cloud temp = list.set(index, element);
    //set this cloud to this element at that index
    list.insertionSort(compare);
    //re-sort this
    return temp;
  }

  @Override
  public int indexOf(Object obj) {
    // look for this object, return what index it at
    return list.indexOf(obj);
  }

  @Override
  public int size() {
    //return size of list
    return list.size();
  }

  @Override
  public boolean add(Cloud e) {
    // TODO Auto-generated method stub
    list.add(e);
    list.insertionSort(compare);
    return true;
  }

  @Override
  public void add(int index, Cloud element) {
    // TODO Auto-generated method stub
    //add this element at this index
    list.add(index, element);
    //resort after adding something
    list.insertionSort(compare);
    
  }

  @Override
  public Cloud remove(int index) {
    //remove the thing at this index
    return list.remove(index);
    //don't need to re-sort this time
  }
  
 

}
