package edu.ics211.h04;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.ics211.h02.Cloud;

/**This is my code.
 * @author Ruben Jacobo
 *     Assisted by Gavin,Louie
 *     inspired by Cam Moore
 *
 */
class SortableListTest {

  /**To test my code I called each method from SortableList. Each time I created a new list
   * integers and implemented the methods from SortableList to make sure they
   *  work in a real situation.
   *  When adding new integers in specific order, I could call the get method at each index
   *   and ensure they were added correctly.
   * For the sorting methods, I first added integers that were already sorted in ascending order
   *  to test that the number of comparisons and swaps were correct on an already sorted list.
   *   I then added an extra integer that was out of order
   *  and tracked the expected number of comparisons and swaps to ensure
   *  they were being kept track of correctly
   *
   * 
   */
  @BeforeEach
  void setUp() throws Exception {
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#SortableList()}.
   */
  @Test
  void testSortableList() {
    SortableList<Integer> list = new SortableList<Integer>();
    assertNotNull(list);
    //make sure list exists
    assertEquals(Integer.valueOf(0), list.size());
    //nothing in the list yet, size is 0
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#get(int)}.
   */
  @Test
  void testGet() {
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(4);
    list.add(2);
    list.add(0);
    // try some good values
    assertEquals(0, list.get(2));
    assertEquals(2, list.get(1));
    assertEquals(4, list.get(0));
    // try some bad values
    try {
      list.get(-1);
      fail("Didn't throw IndexOutOfBoundsException for index -1");
    } catch (IndexOutOfBoundsException ioobe) {
      // this is what we want.
    }
    try {
      list.get(list.size());
      fail("Didn't throw IndexOutOfBoundsException for index size");
    } catch (IndexOutOfBoundsException ioobe) {
      // this is what we want.
    }
   
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#set(int, java.lang.Object)}.
   */
  @Test
  void testSet() {
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(4);
    list.add(2);
    list.add(0);
    // try some good values
    int old = list.set(0, 1);
    assertEquals(4, old);
    assertEquals(1, list.get(0));
    // try some bad values
    try {
      list.set(-1, old);
      fail("Didn't throw IndexOutOfBoundsException for index -1");
    } catch (IndexOutOfBoundsException ioobe) {
      // this is what we want.
    }
    try {
      list.set(list.size(), old);
      fail("Didn't throw IndexOutOfBoundsException for index size");
    } catch (IndexOutOfBoundsException ioobe) {
      // this is what we want.
    }
    
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#indexOf(java.lang.Object)}.
   */
  @Test
  void testIndexOf() {
   
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(4);
    list.add(2);
    list.add(0);
    // try some good values
    assertTrue("Got wrong index", list.indexOf(0) == 2);
    assertTrue("Got wrong index", list.indexOf(2) == 1);
    assertTrue("Got wrong index", list.indexOf(4) == 0);
    // try a value not in the list
    assertTrue("Got wrong index", list.indexOf(1) == -1);
    //if its not in the list, it will return index -1
    //pass
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#size()}.
   */
  @Test
  void testSize() {
    
    SortableList<Integer> list = new SortableList<Integer>();
    assertEquals(0, list.size());
    //size is 0 when theres nothing in there
    list.add(4);
    //add something, size is now 1
    assertEquals(1, list.size());
    list.add(2);
    //add another, size is now 2
    assertEquals(2, list.size());
    list.add(0);
    //add another, expected is 3
    assertEquals(3, list.size());
    list.remove(0);
    assertEquals(2, list.size());
    
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#add(java.lang.Object)}.
   */
  @Test
  void testAddE() {
    
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(4);
    assertEquals(1, list.size());
    //add one thing, size is now 1
    assertEquals(4, list.get(0));
    //value at index 0, is 4
    list.add(2);
    assertEquals(2, list.size());
    assertEquals(4, list.get(0));
    assertEquals(2, list.get(1));
    list.add(0);
    assertEquals(3, list.size());
    //last item in the list should be 0 because it just got added
    assertEquals(0, list.get(2));
    assertEquals(2, list.get(1));
    // at index  1, should be 2
    
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#add(int, java.lang.Object)}.
   */
  @Test
  void testAddIntE() {
    
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(0, 4);
    assertEquals(1, list.size());
    //make sure it added by getting the size of the list
    assertEquals(4, list.get(0));
    //retrieve value at index 0, should be 4
    list.add(1, 2);
    assertEquals(2, list.size());
    //make sure new value added
    assertEquals(4, list.get(0));
    assertEquals(2, list.get(1));
    list.add(2, 0);
    assertEquals(3, list.size());
    //values should now be 4,2,0 in that order
    //we check it now
    assertEquals(4, list.get(0));
    assertEquals(2, list.get(1));
    assertEquals(0, list.get(2));
    // try some bad values
    try {
      list.add(-1, 1);
      fail("Didn't throw IndexOutOfBoundsException for index -1");
    } catch (IndexOutOfBoundsException ioobe) {
      // this is what we want
    }
    try {
      list.add(list.size() + 1, 1);
      fail("Didn't throw IndexOutOfBoundsException for index size + 1");
    } catch (IndexOutOfBoundsException ioobe) {
      // this is what we want
    }
    //pass
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#remove(int)}.
   */
  @Test
  void testRemove() {
   
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(4);
    list.add(2);
    list.add(0);
    // try some bad values
    try {
      list.remove(-1);
      fail("Didn't throw IndexOutOfBoundsException for index -1");
    } catch (IndexOutOfBoundsException ioobe) {
      // this is what we want.
    }
    try {
      list.remove(list.size());
      fail("Didn't throw IndexOutOfBoundsException for index size");
    } catch (IndexOutOfBoundsException ioobe) {
      // this is what we want
    }
    // try some good values
    int removed = list.remove(1); 
    //remove value 2
    assertEquals(removed, 2);
    assertEquals(2, list.size());
    removed = list.remove(0); 
    //remove value 4
    assertEquals(removed, 4);
    //list size will shrink because things got removed
    assertEquals(1, list.size());
    removed = list.remove(0);
    assertEquals(removed, 0);
    //everything removed, list size should be 0
    assertEquals(0, list.size());
    
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#insertionSort(java.util.Comparator)}.
   */
  @Test
  void testInsertionSort() {
    SortableList<Integer> list = new SortableList<Integer>();
    //create a new list
    list.add(7);
    list.add(2);
    list.add(5);
    list.add(3);
    //added some values
    list.insertionSort(new IntegerComparator());
    //sort it with insertion sort
    assertEquals(Integer.valueOf(2), list.get(0));
    assertEquals(Integer.valueOf(3), list.get(1));
    assertEquals(Integer.valueOf(5), list.get(2));
    //order should now be 2,3,5,7
    //passed
      
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#bubbleSort(java.util.Comparator)}.
   */
  @Test
  void testBubbleSort() {
    SortableList<Integer> list = new SortableList<Integer>();
    //make a new list
    list.add(2);
    list.add(5);
    list.add(7);
    list.add(3);
    //add values to this list
    list.bubbleSort(new IntegerComparator());
    //use bubble sort to sort these
    assertEquals(Integer.valueOf(2), list.get(0));
    assertEquals(Integer.valueOf(3), list.get(1));
    assertEquals(Integer.valueOf(5), list.get(2));
    //order of the values should now be 2,3,5,7
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#selectionSort(java.util.Comparator)}.
   */
  @Test
  void testSelectionSort() {
    // create a SortableList<Integer>
    SortableList<Integer> list = new SortableList<Integer>();
    // add numbers 23 , 54 , 12 to test
    list.add(2);
    list.add(5);
    list.add(1);
    // sort numbers
    list.selectionSort(new IntegerComparator());
    // test the expected order
    assertEquals(1, list.get(0));
    assertEquals(2, list.get(1));
    assertEquals(5, list.get(2));
  
   
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#getNumberOfSwaps()}.
   */
  @Test
  void testGetNumberOfSwaps() {
    // make new list
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(1);
    list.add(2);
    list.add(3);
    //add values to list
    list.insertionSort(new IntegerComparator());
    //insertion sort
    assertEquals(list.getNumberOfSwaps(), 0);
    //test how much swaps there would be with an already sorted list
    list.add(0);
    //add 0 to mess up the sort
    list.insertionSort(new IntegerComparator());
    assertEquals(list.getNumberOfSwaps(), 3);
    //track how much swaps now that the array is resorted
    
    
    SortableList<Integer> list2 = new SortableList<Integer>();
    list2.add(1);
    list2.add(2);
    list2.add(3);
    //add values to list in ascending order already
    list2.bubbleSort(new IntegerComparator());
    //bubble sort it
    assertEquals(list2.getNumberOfSwaps(), 0);
    //there should be no swaps because sorted already
    list2.add(0);
    //adding a 0 messed up the order
    list2.bubbleSort(new IntegerComparator());
    assertEquals(list2.getNumberOfSwaps(), 3);
    //resort and check if swaps are correct
    
    
    SortableList<Integer> list3 = new SortableList<Integer>();
    list3.add(1);
    list3.add(2);
    list3.add(3);
    //add values already in ascending order
    list3.selectionSort(new IntegerComparator());
    //insertion sort
    assertEquals(0, list3.getNumberOfSwaps());
    //there should be no swaps because already sorted
    list3.add(0);
    //add a 0 to mess up order
    list3.selectionSort(new IntegerComparator());
    //resort 
    assertEquals(3, list3.getNumberOfSwaps());
    // 3 swaps expected now because order messed up
    
    
    
    
    
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#getNumberOfComparisons()}.
   */
  @Test
  void testGetNumberOfComparisons() {
    
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(1);
    list.add(2);
    list.add(3);
    //add random values to list
    list.selectionSort(new IntegerComparator());
    //selection sort
    assertEquals(3, list.getNumberOfComparisons());
    //3 comparisons when list is already sorted
    list.add(0);
    //add 0 to mess up sorted list
    list.selectionSort(new IntegerComparator());
    assertEquals(6, list.getNumberOfComparisons());
    //expected 6 comparisons after resort
    
    
    SortableList<Integer> list2 = new SortableList<Integer>();
    list2.add(1);
    list2.add(2);
    list2.add(3);
    //random values added in ascending order
    list2.bubbleSort(new IntegerComparator());
    //bubble sort it
    assertEquals(2, list2.getNumberOfComparisons());
    //2 comparisons expected when already ascending
    list2.add(0);
    //add 0 to throw it off
    list2.bubbleSort(new IntegerComparator());
    assertEquals(6, list2.getNumberOfComparisons());
    //6 comparisons after resort
    
    
    SortableList<Integer> list3 = new SortableList<Integer>();
    list3.add(1);
    list3.add(2);
    list3.add(3);
    //add random values in ascending order
    list3.insertionSort(new IntegerComparator());
    //insertion sort it
    assertEquals(2, list3.getNumberOfComparisons());
    //expected comparisons is 2 when list is already ascending
    list3.add(0);
    //add 0 to throw it off
    list3.insertionSort(new IntegerComparator());
    assertEquals(5, list3.getNumberOfComparisons());
    //expected 5 comparisons after resort
    
  }


  /**
   * Test method for {@link edu.ics211.h04.SortableList#getSortTime()}.
   */
  @Test
  void testGetSortTime() {
    
    SortableList<Integer> list = new SortableList<Integer>();
    list.add(7);
    list.add(2);
    list.add(5);
    list.add(3);
    //add random values to list
    list.insertionSort(new IntegerComparator());
    //test insertion sort time
    if (list.getSortTime() <= 0) {
      fail("did not sort time good");
    }
    //time should not be 0 or negative number
    
    SortableList<Integer> list2 = new SortableList<Integer>();
    list2.add(7);
    list2.add(2);
    list2.add(5);
    list2.add(3);
    //random values to be sorted
    list2.bubbleSort(new IntegerComparator());
    //testing bubbleSort time
    if (list2.getSortTime() <= 0) {
      fail("did not sort time good");
    }
    //time should not be 0 or a negative number
    
    SortableList<Integer> list3 = new SortableList<Integer>();
    list3.add(7);
    list3.add(2);
    list3.add(5);
    list3.add(3);
    //add random numbers to the list
    list3.selectionSort(new IntegerComparator());
    //test the selection sort method time
    if (list3.getSortTime() <= 0) {
      fail("did not sort time good");
    }
    //getSortTime should not be 0 and should not be negative
    
  }

}
