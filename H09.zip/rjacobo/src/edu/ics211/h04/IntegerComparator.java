package edu.ics211.h04;

import java.util.Comparator;

public class IntegerComparator implements Comparator<Integer> {

  @Override
  //compares two integers
  public int compare(Integer o1, Integer o2) {
    //compares two integers
    return o1.compareTo(o2);
  }

}
